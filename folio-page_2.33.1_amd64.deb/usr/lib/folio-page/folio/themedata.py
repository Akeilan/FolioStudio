"""Design tab data: colour schemes (dk1, lt1, dk2, lt2, accent1-6, hyperlink,
followed hyperlink), font schemes (headings, body) and themes combining them."""

COLOR_SCHEMES = {
    "Standard": "000000 FFFFFF 44546A E7E6E6 4472C4 ED7D31 A5A5A5 FFC000 5B9BD5 70AD47 0563C1 954F72",
    "Standard 2023": "000000 FFFFFF 0E2841 E8E8E8 156082 E97132 196B24 0F9ED5 A02B93 4EA72E 467886 96607D",
    "Standard 2007": "000000 FFFFFF 1F497D EEECE1 4F81BD C0504D 9BBB59 8064A2 4BACC6 F79646 0000FF 800080",
    "Grayscale": "000000 FFFFFF 000000 F8F8F8 DDDDDD B2B2B2 969696 808080 5F5F5F 4D4D4D 5F5F5F 919191",
    "Blue Warm": "000000 FFFFFF 242852 ACCBF9 4A66AC 629DD1 297FD5 7F8FA9 5AA2AE 9D90A0 9454C3 3EBBF0",
    "Blue": "000000 FFFFFF 17406D DBEFF9 0F6FC6 009DD9 0BD0D9 10CF9B 7CCA62 A5C249 F49100 85DFD0",
    "Blue II": "000000 FFFFFF 335B74 DFE3E5 1CADE4 2683C6 27CED7 42BA97 3E8853 62A39F 6B9F25 B26B02",
    "Blue Green": "000000 FFFFFF 373545 CEDBE6 3494BA 58B6C0 75BDA7 7A8C8E 84ACB6 2683C6 6B9F25 9F6715",
    "Green": "000000 FFFFFF 455F51 E3DED1 549E39 8AB833 C0CF3A 029676 4AB5C4 0989B1 6B9F25 BA6906",
    "Green Yellow": "000000 FFFFFF 455F51 E2DFCC 99CB38 63A537 37A76F 44C1A3 4EB3CF 51C3F9 EE7B08 977B2D",
    "Yellow": "000000 FFFFFF 39302A E5DEDB FFCA08 F8931D CE8D3E EC7016 E64823 9C6A6A 2998E3 7F723D",
    "Yellow Orange": "000000 FFFFFF 4E3B30 FBEEC9 F0A22E A5644E B58B80 C3986D A19574 C17529 AD1F1F FFC42F",
    "Orange": "000000 FFFFFF 637052 CCDDEA E48312 BD582C 865640 9B8357 C2BC80 94A088 2998E3 8C8C8C",
    "Orange Red": "000000 FFFFFF 696464 E9E5DC D34817 9B2D1F A28E6A 956251 918485 855D5D CC9900 96A9A9",
    "Red Orange": "000000 FFFFFF 505046 EEECE1 E84C22 FFBD47 B64926 FF8427 CC9900 B22600 CC9900 666699",
    "Red": "000000 FFFFFF 323232 E5C243 A5300F D55816 E19825 B19C7D 7F5F52 B27D49 6B9F25 B26B02",
    "Red Violet": "000000 FFFFFF 454551 D8D9DC E32D91 C830CC 4EA6DC 4775E7 8971E1 D54773 6B9F25 8C8C8C",
    "Violet": "000000 FFFFFF 373545 DCD8DC AD84C6 8784C7 5D739A 6997AF 84ACB6 6F8183 69A020 8C8C8C",
    "Violet II": "000000 FFFFFF 632E62 EAE5EB 92278F 9B57D3 755DD9 665EB8 45A5ED 5982DB 0066FF 666699",
    "Median": "000000 FFFFFF 775F55 EBDDC3 94B6D2 DD8047 A5AB81 D8B25C 7BA79D 968C8C F7B615 704404",
    "Paper": "000000 FFFFFF 444D26 FEFAC9 A5B592 F3A447 E7BC29 D092A7 9C85C0 809EC2 8E58B6 7F6F6F",
    "Marquee": "000000 FFFFFF 5E5E5E DDDDDD 418AB3 A6B727 F69200 838383 FEC306 DF5327 F59E00 B2B2B2",
    "Slipstream": "000000 FFFFFF 212745 B4DCFA 4E67C8 5ECCF3 A7EA52 5DCEAF FF8021 F14124 56C7AA 59A8D1",
    "Aspect": "000000 FFFFFF 323232 E3DED1 F07F09 9F2936 1B587C 4E8542 604878 C19859 6B9F25 B26B02",
}
COLOR_SCHEMES = {k: [int(x, 16) for x in v.split()] for k, v in COLOR_SCHEMES.items()}

FONT_SCHEMES = {
    "Standard": ("Calibri Light", "Calibri"),
    "Standard 2023": ("Aptos Display", "Aptos"),
    "Standard 2007": ("Cambria", "Calibri"),
    "Calibri": ("Calibri", "Calibri"),
    "Arial": ("Arial", "Arial"),
    "Cambria": ("Cambria", "Cambria"),
    "Georgia": ("Georgia", "Georgia"),
    "Times New Roman": ("Times New Roman", "Times New Roman"),
    "Calibri-Cambria": ("Calibri", "Cambria"),
    "Arial-Times New Roman": ("Arial", "Times New Roman"),
    "Candara": ("Candara", "Candara"),
    "Constantia": ("Constantia", "Constantia"),
    "Liberation Sans": ("Liberation Sans", "Liberation Sans"),
    "Liberation Serif": ("Liberation Serif", "Liberation Serif"),
    "DejaVu": ("DejaVu Sans", "DejaVu Serif"),
}

THEMES = {
    "Default": ("Standard", "Standard"),
    "Default 2023": ("Standard 2023", "Standard 2023"),
    "Classic": ("Standard 2007", "Standard 2007"),
    "Slate": ("Grayscale", "Arial"),
    "Meadow": ("Green", "Calibri-Cambria"),
    "Ember": ("Red Orange", "Georgia"),
    "Lagoon": ("Blue Green", "Calibri"),
    "Royal": ("Violet II", "Constantia"),
    "Harbor": ("Blue II", "Cambria"),
    "Paperback": ("Paper", "Times New Roman"),
    "Marquee": ("Marquee", "Arial-Times New Roman"),
    "Slipstream": ("Slipstream", "Candara"),
}

# Design > Paragraph Spacing: (before pt, after pt, line spacing %)
SPACING = {
    "default": (0, 8, 108),
    "none": (0, 0, 100),
    "compact": (0, 4, 100),
    "tight": (0, 6, 115),
    "open": (0, 10, 115),
    "relaxed": (0, 6, 150),
    "double": (0, 8, 200),
}


def shade(c, k):
    """A colour darkened toward black by k (0..1)."""
    return (int(((c >> 16) & 255) * k) << 16) | (int(((c >> 8) & 255) * k) << 8) | int((c & 255) * k)
