"""Folio Reel: a video editor — clips on a timeline, titles, music, export to a file you can share."""
import os

VERSION = "0.18.0"
APP_NAME = "Folio Reel"
APP_ID = "org.folio.Reel"
SHARE = (os.environ.get("FOLIO_REEL_SHARE")
         or (os.path.join(os.environ["FOLIO_ROOT"], "share", "folio-reel") if os.environ.get("FOLIO_ROOT") else None)
         or "/usr/share/folio-reel")
