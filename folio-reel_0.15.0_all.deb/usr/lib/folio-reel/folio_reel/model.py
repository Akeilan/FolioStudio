"""A Reel project: the media bin and four tracks of clips (R3-01), saved as JSON (.reel).

Times are seconds (floats). Every edit goes through Project's methods, which keep the tracks in
order and record undo steps.

  Tracks (top to bottom in the picture):  titles (overlay), video, audio, music
  A clip:  {"id", "kind": media|title|lower-third|caption, "media": uri, "name", "start",
            "inpoint", "duration" (on the timeline), "speed", "volume", "fade_in", "fade_out",
            "color": {brightness, contrast, saturation, hue}, "crop": {l, r, t, b} (fractions),
            "zoom", "panzoom": None|"in"|"out"|"left"|"right", "transition": None|{type, duration},
            "music_bed", "keyframes": [[t, level], ...], text, font, text_color, bg_color, ...}
"""
import copy
import json
import os
import time

TRACKS = ["titles", "video", "audio", "music"]
TRACK_NAMES = {"titles": "Titles", "video": "Video", "audio": "Audio", "music": "Music"}
IMAGE_SECONDS = 5.0
TITLE_SECONDS = 4.0
TRANSITIONS = [("crossfade", "Crossfade"), ("dip-black", "Fade to Black"), ("wipe-right", "Wipe Right"),
               ("wipe-left", "Wipe Left"), ("wipe-down", "Wipe Down"), ("wipe-up", "Wipe Up"),
               ("box", "Box"), ("clock", "Clock"), ("iris", "Iris")]
PRESETS = {"720p": (1280, 720), "1080p": (1920, 1080), "4k": (3840, 2160)}
# Named export presets (R4-08): what it is called, the format, and the size.
EXPORT_PRESETS = [
    ("Full HD video (MP4, 1080p)", "mp4", "1080p"),
    ("4K video (MP4)", "mp4", "4k"),
    ("Smaller file (MP4, 720p)", "mp4", "720p"),
    ("For the web (WebM, 1080p)", "webm", "1080p"),
    ("For the web, smaller (WebM, 720p)", "webm", "720p"),
]
EPS = 1e-6


def new_project(width=1920, height=1080, fps=30):
    return {"version": 1, "width": width, "height": height, "fps": fps, "media": [],
            "tracks": {t: [] for t in TRACKS}, "markers": [], "next_id": 1}


MARKER_COLORS = [("yellow", "Yellow"), ("red", "Red"), ("green", "Green"), ("blue", "Blue"),
                 ("purple", "Purple"), ("white", "White")]
MARKER_RGB = {"yellow": (0.98, 0.78, 0.10), "red": (0.85, 0.20, 0.18), "green": (0.22, 0.70, 0.30),
              "blue": (0.20, 0.52, 0.90), "purple": (0.60, 0.35, 0.85), "white": (0.95, 0.95, 0.95)}


def clip_defaults():
    return {"speed": 1.0, "volume": 1.0, "fade_in": 0.0, "fade_out": 0.0,
            "color": {"brightness": 0.0, "contrast": 1.0, "saturation": 1.0, "hue": 0.0},
            "crop": {"l": 0.0, "r": 0.0, "t": 0.0, "b": 0.0}, "zoom": 1.0, "panzoom": None,
            "transition": None, "music_bed": False, "keyframes": [], "muted": False,
            "chroma": False, "chroma_color": "green", "chroma_tolerance": 20.0,
            "chroma_softness": 2.0, "chroma_edges": 100,
            "steady": False, "steady_amount": 5, "lens": 0.0,
            "sound_elsewhere": False}       # its own sound is a clip on a sound track (R5-05)


def end_of(c):
    return c["start"] + c["duration"]


class EditError(Exception):
    """An edit that can't be made (the message says why)."""


class Project:
    def __init__(self, data=None, path=None):
        self.data = data or new_project()
        for t in TRACKS:
            self.data["tracks"].setdefault(t, [])
        self.data.setdefault("markers", [])      # R4-05: older projects have none
        self.path = path
        self.undo_stack = []
        self.redo_stack = []
        self.listeners = []
        self.dirty = False
        self.snapping = True
        self._batch = 0                 # edits inside a batch are one undo step (R9-29)
        self._batch_made = False
        self._batch_label = ""
        self._saved = self._stamp()     # how the project read when it was last saved (R9-31)
        self.missing = set()            # media whose file isn't there (R9-02)
        self.refresh_missing()

    # ------------------------------------------------------------ change notification and undo
    def listen(self, fn):
        self.listeners.append(fn)

    def _changed(self, what="timeline"):
        self.dirty = True
        for fn in list(self.listeners):
            fn(what)

    def _stamp(self):
        return hash(json.dumps(self.data, sort_keys=True, default=str))

    def mark_saved(self):
        self._saved = self._stamp()
        self.dirty = False

    def batch(self, label=""):
        """with project.batch("Speed"): ... — every edit inside is one step for Undo (R9-29)."""
        return _Batch(self, label)

    def checkpoint(self, label="", merge=None):
        """Before an edit: remember how things were, for Undo. merge: a key; another change with the
        same key straight after (a slider being dragged) joins this undo step."""
        if self._batch:
            if self._batch_made:
                return
            self._batch_made = True
            label = self._batch_label or label
            merge = None
        now = time.monotonic()
        last = getattr(self, "_merge", None)
        self._merge = (merge, now) if merge is not None else None
        if merge is not None and last and last[0] == merge and now - last[1] < 1.5 and self.undo_stack:
            self.redo_stack.clear()
            return
        self.undo_stack.append((label, copy.deepcopy(self.data)))
        if len(self.undo_stack) > 200:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def can_undo(self):
        return bool(self.undo_stack)

    def can_redo(self):
        return bool(self.redo_stack)

    def undo_label(self):
        return self.undo_stack[-1][0] if self.undo_stack else None

    def redo_label(self):
        return self.redo_stack[-1][0] if self.redo_stack else None

    def undo(self):
        self._merge = None
        if not self.undo_stack:
            return None
        label, data = self.undo_stack.pop()
        self.redo_stack.append((label, copy.deepcopy(self.data)))
        self.data = data
        self._changed("all")
        self.dirty = self._stamp() != self._saved        # back as it was saved: nothing to save (R9-31)
        return label

    def redo(self):
        self._merge = None
        if not self.redo_stack:
            return None
        label, data = self.redo_stack.pop()
        self.undo_stack.append((label, copy.deepcopy(self.data)))
        self.data = data
        self._changed("all")
        self.dirty = self._stamp() != self._saved
        return label

    # ------------------------------------------------------------ settings
    @property
    def width(self):
        return self.data["width"]

    @property
    def height(self):
        return self.data["height"]

    @property
    def fps(self):
        return self.data["fps"]

    def set_size(self, width, height, fps=None):
        self.checkpoint("Project Size")
        self.data["width"], self.data["height"] = int(width), int(height)
        if fps:
            self.data["fps"] = fps
        self._changed()

    # ------------------------------------------------------------ media bin
    @property
    def media(self):
        return self.data["media"]

    def media_by_uri(self, uri):
        for m in self.data["media"]:
            if m["uri"] == uri:
                return m
        return None

    def add_media(self, info):
        """info: {"uri", "name", "duration", "has_video", "has_audio", "is_image", "width", "height"}"""
        old = self.media_by_uri(info["uri"])
        if old:
            return old
        self.checkpoint("Import Media")
        self.data["media"].append(dict(info))
        self._changed("media")
        return info

    def refresh_missing(self):
        """Look again for the media files: which are not there (R9-02)."""
        self.missing = {m["uri"] for m in self.data.get("media", [])
                        if uri_to_path(m["uri"]) and not os.path.exists(uri_to_path(m["uri"]))}
        return self.missing

    def relink_media(self, uri, info):
        """Point a media entry, and every clip made from it, at another file (R9-02). info is what
        the new file is (engine.probe). Clips keep their place; one that would now run past the end
        of a shorter file is shortened."""
        m = self.media_by_uri(uri)
        if m is None:
            raise EditError("no such media")
        other = self.media_by_uri(info["uri"])
        if other is not None and other is not m:
            raise EditError("“%s” is already in this project." % other["name"])
        self.checkpoint("Find File")
        m.clear()
        m.update(dict(info))
        for c in self.all_clips():
            if c.get("media") == uri:
                c["media"] = info["uri"]
                if not info.get("is_image"):
                    most = max(0.04, (float(info["duration"]) - c["inpoint"]) / c.get("speed", 1.0))
                    if c["duration"] > most:
                        c["duration"] = most
        self.refresh_missing()
        self._changed("all")
        return m

    def remove_media(self, uri):
        used = [c for c in self.all_clips() if c.get("media") == uri]
        if used:
            raise EditError("“%s” is used in the timeline: remove those clips first." % self.media_by_uri(uri)["name"])
        self.checkpoint("Remove Media")
        self.data["media"] = [m for m in self.data["media"] if m["uri"] != uri]
        self._changed("media")

    # ------------------------------------------------------------ looking things up
    def track(self, name):
        return self.data["tracks"][name]

    def all_clips(self):
        for t in TRACKS:
            for c in self.data["tracks"][t]:
                yield c

    def find(self, cid):
        for t in TRACKS:
            for c in self.data["tracks"][t]:
                if c["id"] == cid:
                    return t, c
        return None, None

    def clip(self, cid):
        return self.find(cid)[1]

    def duration(self):
        return max([end_of(c) for c in self.all_clips()] + [0.0])

    def picture_spans(self):
        """[(from, to)] of the film that has something to look at: a clip on the Video or Titles
        track that is not itself invisible. Overlapping clips are merged into one span (R5-02)."""
        spans = []
        for name in ("video", "titles"):
            for c in self.track(name):
                if self.clip_shows_nothing(c):
                    continue
                spans.append((c["start"], end_of(c)))
        spans.sort()
        out = []
        for a, b in spans:
            if out and a <= out[-1][1] + EPS:
                out[-1] = (out[-1][0], max(out[-1][1], b))
            else:
                out.append((a, b))
        return out

    @staticmethod
    def clip_shows_nothing(c):
        """True for a clip that draws nothing you could see: turned all the way down to black, or
        a title with no words and nothing behind them (R5-02)."""
        col = c.get("color") or {}
        if col.get("brightness", 0.0) <= -0.99 or col.get("contrast", 1.0) <= 0.0:
            return True
        if c["kind"] != "media" and not (c.get("text") or "").strip():
            bg = (c.get("bg_color") or "#ff000000").lstrip("#")
            if len(bg) == 8 and int(bg[:2], 16) == 0:
                return True
        return False

    def dark_spans(self, floor=0.25):
        """[(from, to)] of the film with nothing to look at, longer than `floor` seconds: the film
        would be black there. The film's own length bounds it (R5-02)."""
        total = self.duration()
        if total <= 0:
            return []
        out, at = [], 0.0
        for a, b in self.picture_spans():
            if a > at + floor:
                out.append((at, a))
            at = max(at, b)
        if total > at + floor:
            out.append((at, total))
        return out

    def clips_at(self, t):
        return [c for c in self.all_clips() if c["start"] - EPS <= t < end_of(c) - EPS]

    def _sort(self, track):
        self.data["tracks"][track].sort(key=lambda c: (c["start"], c["id"]))

    def neighbours(self, cid):
        """(previous clip, next clip) on the same track."""
        track, c = self.find(cid)
        if c is None:
            return None, None
        lst = self.data["tracks"][track]
        i = lst.index(c)
        return (lst[i - 1] if i > 0 else None), (lst[i + 1] if i + 1 < len(lst) else None)

    def snap_points(self, exclude=()):
        pts = {0.0}
        for c in self.all_clips():
            if c["id"] in exclude:
                continue
            pts.add(c["start"])
            pts.add(end_of(c))
        for m in self.data.get("markers", []):      # clips snap to markers as well (R4-05)
            pts.add(m["t"])
        return sorted(pts)

    def snap(self, t, tolerance, exclude=(), extra=()):
        """t moved to the nearest clip edge (or extra point, e.g. the playhead) within tolerance."""
        if not self.snapping:
            return t
        best, dist = t, tolerance
        for p in list(self.snap_points(exclude)) + list(extra):
            if abs(p - t) <= dist:
                best, dist = p, abs(p - t)
        return best

    # ------------------------------------------------------------ groups of clips (R4-06)
    def group_of(self, cid):
        """The group a clip belongs to, or None."""
        _t, c = self.find(cid)
        return (c or {}).get("group") or None

    def group_members(self, gid):
        """Every clip in a group, earliest first."""
        if not gid:
            return []
        return sorted([c for c in self.all_clips() if c.get("group") == gid], key=lambda c: c["start"])

    def expand_groups(self, ids):
        """The given clips, plus everything grouped with them (R4-06)."""
        out = list(ids)
        gids = {self.group_of(i) for i in ids} - {None}
        for g in gids:
            for c in self.group_members(g):
                if c["id"] not in out:
                    out.append(c["id"])
        return out

    def group(self, ids):
        """Make the clips one group, which moves and trims as a single clip. Returns the group id."""
        clips = [c for c in self.all_clips() if c["id"] in ids]
        if len(clips) < 2:
            raise EditError("Pick two or more clips to group.")
        self.checkpoint("Group")
        gid = self._new_id()
        for c in clips:
            c["group"] = gid
        self._changed()
        return gid

    def ungroup(self, ids):
        """Break up every group the given clips are in. Returns how many clips were freed."""
        gids = {self.group_of(i) for i in ids} - {None}
        if not gids:
            raise EditError("Those clips aren't grouped.")
        self.checkpoint("Ungroup")
        n = 0
        for c in self.all_clips():
            if c.get("group") in gids:
                c.pop("group", None)
                n += 1
        self._changed()
        return n

    def move_group(self, gid, delta, tolerance=0.0, playhead=None):
        """Slide a whole group along the timeline. Nothing moves unless every clip in it can."""
        members = self.group_members(gid)
        if not members:
            raise EditError("no such group")
        first = members[0]
        start = max(0.0, first["start"] + delta)
        if tolerance:
            ids = [c["id"] for c in members]
            last_end = max(end_of(c) for c in members)
            extra = [playhead] if playhead is not None else []
            s1 = self.snap(start, tolerance, exclude=ids, extra=extra)
            s2 = self.snap(start + (last_end - first["start"]), tolerance, exclude=ids, extra=extra) - (last_end - first["start"])
            moved = [s for s in (s1, s2) if abs(s - start) > 1e-9]
            if moved:
                start = min(moved, key=lambda s: abs(s - start))
        delta = start - first["start"]
        if abs(delta) < EPS:
            return 0.0
        ids = {c["id"] for c in members}
        for c in members:
            at = c["start"] + delta
            if at < -EPS:
                raise EditError("The group would run off the start of the timeline.")
            track = self.find(c["id"])[0]
            for x in self.data["tracks"][track]:
                if x["id"] in ids:
                    continue
                if not (end_of(x) <= at + EPS or x["start"] >= at + c["duration"] - EPS):
                    raise EditError("Something is in the way of the group there.")
        self.checkpoint("Move group")
        for c in members:
            c["start"] = max(0.0, c["start"] + delta)
        for t in TRACKS:
            self._sort(t)
        for t in ("video", "titles"):
            self._settle(t)
        self._changed()
        return delta

    # ------------------------------------------------------------ markers (R4-05)
    def markers(self):
        """The markers, earliest first."""
        return sorted(self.data.get("markers", []), key=lambda m: m["t"])

    def marker(self, mid):
        for m in self.data.get("markers", []):
            if m["id"] == mid:
                return m
        return None

    def marker_at(self, t, tolerance=0.0):
        """The marker nearest t within tolerance, or None."""
        best, dist = None, tolerance
        for m in self.markers():
            d = abs(m["t"] - t)
            if d <= dist:
                best, dist = m, d
        return best

    def add_marker(self, t, name="", color="yellow"):
        """Put a marker at t. A marker already there is renamed rather than doubled up."""
        t = max(0.0, float(t))
        here = self.marker_at(t, EPS)
        if here is not None:
            if name:
                self.set_marker(here["id"], name=name, color=color)
            return here["id"]
        self.checkpoint("Add marker")
        m = {"id": self._new_id(), "t": t, "name": name, "color": color if color in MARKER_RGB else "yellow"}
        self.data.setdefault("markers", []).append(m)
        self._changed()
        return m["id"]

    def set_marker(self, mid, label="Change marker", **props):
        m = self.marker(mid)
        if m is None:
            return False
        if all(m.get(k) == v for k, v in props.items()):
            return True
        self.checkpoint(label)
        for k, v in props.items():
            if k == "t":
                v = max(0.0, float(v))
            m[k] = v
        self._changed()
        return True

    def remove_markers(self, ids):
        ids = [i for i in ids if self.marker(i) is not None]
        if not ids:
            return 0
        self.checkpoint("Delete marker" if len(ids) == 1 else "Delete markers")
        self.data["markers"] = [m for m in self.data.get("markers", []) if m["id"] not in ids]
        self._changed()
        return len(ids)

    def clear_markers(self):
        return self.remove_markers([m["id"] for m in self.markers()])

    def next_marker(self, t):
        """The first marker after t, or None."""
        for m in self.markers():
            if m["t"] > t + EPS:
                return m
        return None

    def prev_marker(self, t):
        for m in reversed(self.markers()):
            if m["t"] < t - EPS:
                return m
        return None

    # ------------------------------------------------------------ making clips
    def _new_id(self):
        n = self.data["next_id"]
        self.data["next_id"] = n + 1
        return n

    def _media_clip(self, m):
        c = {"id": self._new_id(), "kind": "media", "media": m["uri"], "name": m["name"], "start": 0.0,
             "inpoint": 0.0, "duration": IMAGE_SECONDS if m.get("is_image") else max(0.04, float(m["duration"]))}
        c.update(clip_defaults())
        return c

    def _text_clip(self, kind, text):
        c = {"id": self._new_id(), "kind": kind, "name": text.split("\n")[0][:40] or kind.title(), "start": 0.0,
             "inpoint": 0.0, "duration": TITLE_SECONDS, "text": text}
        c.update(clip_defaults())
        if kind == "title":
            c.update({"font": "Sans Bold 64", "text_color": "#ffffffff", "bg_color": "#ff000000",
                      "halign": "center", "valign": "center"})
        elif kind == "lower-third":
            c.update({"font": "Sans Bold 36", "text_color": "#ffffffff", "bg_color": "#c0101828",
                      "halign": "left", "valign": "bottom"})
        else:   # caption
            c.update({"font": "Sans 30", "text_color": "#ffffffff", "bg_color": "#a0000000",
                      "halign": "center", "valign": "bottom"})
        return c

    def media_kind_track(self, m):
        """Where a piece of media goes by default."""
        if m.get("has_video") or m.get("is_image"):
            return "video"
        return "audio"

    def max_duration(self, c):
        """How long a clip can be on the timeline (media length after its in point, at its speed)."""
        if c["kind"] != "media":
            return float("inf")
        m = self.media_by_uri(c["media"])
        if m is None or m.get("is_image"):
            return float("inf")
        return max(0.04, (float(m["duration"]) - c["inpoint"]) / c.get("speed", 1.0))

    def _make_room(self, track, at, length, exclude=None):
        """Insert edit: every clip on the track starting at or after `at` moves later by `length`;
        a clip running across `at` is split there first (its second half moves too)."""
        lst = self.data["tracks"][track]
        for c in list(lst):
            if c is exclude:
                continue
            if c["start"] < at - EPS < end_of(c) - 2 * EPS and at - c["start"] > EPS:
                self._split(track, c, at)
        self._shift(track, length, at, exclude=exclude)

    def _shift(self, track, delta, at, exclude=None, mirror=True):
        """Move everything on `track` starting at or after `at` along by `delta`, and bring each
        one's grouped partners on other tracks with it. Every ripple on a track goes through here,
        so a picture and the sound split off it cannot be parted by one (R5-05)."""
        if abs(delta) <= 1e-12:
            return
        moved = []
        for c in self.data["tracks"][track]:
            if c is not exclude and c["start"] >= at - EPS:
                c["start"] = max(0.0, c["start"] + delta)
                moved.append(c)
        seen = {c["id"] for c in moved}
        for c in (moved if mirror else []):
            for other in self.group_members(c.get("group")):
                if other["id"] in seen:
                    continue
                t, _o = self.find(other["id"])
                if t != track:
                    other["start"] = max(0.0, other["start"] + delta)
                    seen.add(other["id"])
                    self._sort(t)
        self._sort(track)

    def _ripple(self, tracks, delta, at, exclude=()):
        """Move everything starting at or after `at` on these tracks along by `delta`, and bring
        each moved clip's grouped partners on the other tracks with it. Whatever the route, a clip
        moves once: a picture and its sound, each on a track being rippled, are not carried twice
        (R9-04), and a picture carried along takes its sound with it (R9-05)."""
        if abs(delta) <= 1e-12:
            return
        for c in self._ripple_set(tracks, at, exclude)[0].values():
            c["start"] = max(0.0, c["start"] + delta)
        for t in TRACKS:
            self._sort(t)

    def _room(self, tracks, at, exclude=()):
        """How far a ripple from `at` on these tracks can pull clips earlier before one of the
        clips it carries on another track would land on something that is staying where it is."""
        moved, reached = self._ripple_set(tracks, at, exclude)
        ex = {id(c) for c in exclude}
        room = float("inf")
        for t in reached:
            if t in tracks:
                continue
            starts = [c["start"] for c in self.data["tracks"][t] if c["id"] in moved]
            if not starts:
                continue
            first = min(starts)
            before = max([end_of(c) for c in self.data["tracks"][t]
                          if c["id"] not in moved and id(c) not in ex and c["start"] < first] or [0.0])
            room = min(room, max(0.0, first - before))
        return room

    def _ripple_set(self, tracks, at, exclude=()):
        """({id: clip} a ripple from `at` on these tracks would move, the tracks it reaches). A
        track that holds the partner of a clip being moved is rippled from the same point as well:
        the tracks a film's pictures and sounds share move as one, so nothing lands on a clip that
        stayed behind."""
        ex = {id(c) for c in exclude}
        tracks = list(tracks)
        moved = {}
        grew = True
        while grew:
            grew = False
            for track in tracks:
                for c in self.data["tracks"][track]:
                    if id(c) in ex or c["id"] in moved:
                        continue
                    if c["start"] >= at - EPS:
                        moved[c["id"]] = c
                        grew = True
            for c in list(moved.values()):
                for other in self.group_members(c.get("group")):
                    if id(other) in ex:
                        continue
                    t = self.find(other["id"])[0]
                    if t not in tracks:
                        tracks.append(t)
                        grew = True
                    if other["id"] not in moved:
                        moved[other["id"]] = other
                        grew = True
        return moved, tracks

    def _overlap_in(self, track, c):
        """How far a clip reaches back over the one before it by its own transition."""
        tr = c.get("transition")
        if not tr or tr.get("type") == "dip-black" or track not in ("video", "titles"):
            return 0.0
        return float(tr.get("duration", 0.0))

    def _settle(self, track):
        """After an edit on a picture track: every transition sits exactly over the join it belongs
        to, and no two clips overlap without one (R9-13). A transition whose clips have come apart,
        or whose clip is now first on the track, is taken off; an overlap that is too deep or has
        no transition is undone by moving the later clips along."""
        if track not in ("video", "titles"):
            return
        lst = self.data["tracks"][track]
        self._sort(track)
        for i in range(len(lst)):
            c = lst[i]
            tr = c.get("transition")
            if i == 0:
                if tr:
                    c["transition"] = None
                continue
            prev = lst[i - 1]
            if tr and tr.get("type") != "dip-black":
                d = max(0.1, min(float(tr["duration"]), c["duration"] / 2.0, prev["duration"] / 2.0))
                gap = c["start"] - end_of(prev)
                if gap > 0.05 or min(c["duration"], prev["duration"]) < 0.2:
                    c["transition"] = None          # the two clips came apart, or are too short for one
                    if gap < -EPS:
                        self._ripple([track], -gap, c["start"])
                        lst = self.data["tracks"][track]
                    continue
                tr["duration"] = d
                want = end_of(prev) - d
            else:
                if tr:          # fade to black: no overlap, and no longer than the clips it joins
                    tr["duration"] = max(0.1, min(float(tr["duration"]), c["duration"], prev["duration"]))
                want = max(c["start"], end_of(prev))
            diff = want - c["start"]
            if abs(diff) > EPS:
                self._ripple([track], diff, c["start"])
                lst = self.data["tracks"][track]

    def _first_free(self, track, at, length):
        """The first start at or after `at` where `length` fits on the track."""
        t = at
        for c in sorted(self.data["tracks"][track], key=lambda x: x["start"]):
            if end_of(c) <= t + EPS:
                continue
            if c["start"] >= t + length - EPS:
                break
            t = end_of(c)
        return t

    def add_clip(self, track, source, at=None, insert=False, text=None):
        """source: a media entry (dict with uri) or a text kind ('title', 'lower-third', 'caption').
        at=None: after the last clip on the track. insert=True: clips from `at` on move later."""
        if track not in TRACKS:
            raise EditError("there's no %s track" % track)
        if isinstance(source, dict):
            if track == "titles" and not (source.get("has_video") or source.get("is_image")):
                raise EditError("The Titles track is for pictures, video and titles.")
            if track in ("audio", "music") and not source.get("has_audio"):
                raise EditError("“%s” has no sound to put on the %s track." % (source["name"], TRACK_NAMES[track]))
        self.checkpoint("Add Clip")
        if isinstance(source, dict):
            c = self._media_clip(source)
        else:
            c = self._text_clip(source, text or {"title": "Title", "lower-third": "Name\nRole",
                                                  "caption": "Caption"}.get(source, ""))
        self._place_clip(track, c, at, insert)
        self._changed()
        return c

    def _place_clip(self, track, c, at, insert=False):
        """Put a made clip on a track at `at` (None: after the last one there)."""
        lst = self.data["tracks"][track]
        if at is None:
            at = max([end_of(x) for x in lst] + [0.0])
        at = max(0.0, at)
        if insert:
            self._make_room(track, at, c["duration"])
        else:
            at = self._first_free(track, at, c["duration"])
        c["start"] = at
        lst.append(c)
        self._sort(track)
        return c

    def room_on(self, track, at, length):
        """True if `length` seconds from `at` are free on this track."""
        return abs(self._first_free(track, at, length) - at) < EPS

    def add_media_split(self, track, m, at=None, insert=False, sound_track="audio"):
        """Add media as two clips kept together: the picture on `track` and its own sound on a
        sound track at the very same time, grouped so they move and trim as one (R5-05).

        The pair is only made when the sound can go at exactly the picture's time — sound that
        landed anywhere else would be out of step, which is the whole thing this avoids. Returns
        (picture, sound), with sound None when it stayed with the picture."""
        if track not in ("video", "titles"):
            raise EditError("there's no %s track for pictures" % track)
        if not (m.get("has_video") and m.get("has_audio")) or m.get("is_image"):
            return (self.add_clip(track, m, at=at, insert=insert), None)
        self.checkpoint("Add Clip")
        pic = self._media_clip(m)
        self._place_clip(track, pic, at, insert)
        wanted = [sound_track] + [t for t in ("audio", "music") if t != sound_track]
        where = next((t for t in wanted if self.room_on(t, pic["start"], pic["duration"])), None)
        if where is None:
            self._changed()
            return (pic, None)
        snd = self._media_clip(m)
        snd["name"] = m["name"]
        self._place_clip(where, snd, pic["start"], insert=False)
        gid = self._new_id()
        pic["sound_elsewhere"] = True
        pic["sound_clip"] = snd["id"]
        snd["picture_clip"] = pic["id"]
        pic["group"] = gid
        snd["group"] = gid
        self._changed()
        return (pic, snd)

    def sound_partner(self, cid):
        """The sound clip that carries this picture clip's own sound, or None. The two know each
        other by name, so ungrouping them to nudge one does not lose the pairing (R5-05)."""
        track, c = self.find(cid)
        if c is None or not c.get("sound_elsewhere"):
            return None
        want = c.get("sound_clip")
        if want:
            t, other = self.find(want)
            if other is not None and t in ("audio", "music"):
                return other
        near = [o for o in self.group_members(c.get("group"))
                if self.find(o["id"])[0] in ("audio", "music") and o.get("media") == c.get("media")]
        if near:
            return min(near, key=lambda o: abs(o["start"] - c["start"]))
        return None

    def line_up_sound(self, cid):
        """Put the sound back exactly under its picture: same start, same length, same point into
        the media. The way back after nudging one of them on its own (R5-08)."""
        track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        if not c.get("sound_elsewhere"):
            snd = c
            pic = None
            for other in self.all_clips():
                if other.get("sound_elsewhere") and self.sound_partner(other["id"]) is not None \
                        and self.sound_partner(other["id"])["id"] == cid:
                    pic = other
                    break
            if pic is None:
                raise EditError("That clip isn't the sound of a picture clip.")
        else:
            pic, snd = c, self.sound_partner(cid)
            if snd is None:
                raise EditError("“%s” has no sound clip to line up." % c["name"])
        if abs(snd["start"] - pic["start"]) <= 1e-9 and abs(snd["duration"] - pic["duration"]) <= 1e-9 \
                and abs(snd["inpoint"] - pic["inpoint"]) <= 1e-9:
            return None
        self.checkpoint("Line Up The Sound")
        snd_track = self.find(snd["id"])[0]
        snd["start"] = pic["start"]
        snd["duration"] = pic["duration"]
        snd["inpoint"] = pic["inpoint"]
        snd["speed"] = pic.get("speed", 1.0)
        snd["fade_in"] = min(snd.get("fade_in", 0.0), snd["duration"])
        snd["fade_out"] = min(snd.get("fade_out", 0.0), snd["duration"])
        if not snd.get("group") or snd.get("group") != pic.get("group"):
            gid = pic.get("group") or self._new_id()
            pic["group"] = gid
            snd["group"] = gid
        pic["sound_clip"] = snd["id"]
        snd["picture_clip"] = pic["id"]
        self._sort(snd_track)
        self._changed()
        return snd

    def out_of_step(self, tolerance=None):
        """[(picture, sound)] for every split pair whose two halves no longer line up. The check
        the sound split asks for: nothing here means every picture still has its own sound under
        it, at the same time and for the same length (R5-05)."""
        tol = (1.0 / max(1, self.fps)) if tolerance is None else tolerance
        out = []
        for name in ("video", "titles"):
            for c in self.track(name):
                snd = self.sound_partner(c["id"])
                if snd is None:
                    continue
                if abs(snd["start"] - c["start"]) > tol or abs(snd["duration"] - c["duration"]) > tol:
                    out.append((c, snd))
        return out

    def add_subtitles(self, entries):
        """Subtitles (R4-03) as caption clips on the Titles track, each at its own time. Captions
        already there are left alone; overlapping ones are moved along as any clip would be."""
        if not entries:
            return []
        self.checkpoint("Import Subtitles")
        made = []
        for start, end, words in entries:
            c = self._text_clip("caption", words)
            c["start"] = max(0.0, float(start))
            c["duration"] = max(0.1, float(end) - float(start))
            c["start"] = self._first_free("titles", c["start"], c["duration"])
            self.data["tracks"]["titles"].append(c)
            self._sort("titles")
            made.append(c)
        self._changed()
        return made

    # ------------------------------------------------------------ editing
    def _split(self, track, c, t):
        b = copy.deepcopy(c)
        b["id"] = self._new_id()
        off = t - c["start"]
        c["duration"] = off
        b["start"] = t
        b["duration"] -= off
        b["inpoint"] = c["inpoint"] + off * c.get("speed", 1.0) if c["kind"] == "media" else 0.0
        b["transition"] = None
        b["fade_in"] = 0.0
        c["fade_out"] = 0.0
        # the halves cannot both claim the same partner by name: the group finds the right one
        for half in (b, c):
            half.pop("sound_clip", None)
            half.pop("picture_clip", None)
        b["keyframes"] = [[k - off, v] for k, v in c.get("keyframes", []) if k >= off]
        c["keyframes"] = [[k, v] for k, v in c.get("keyframes", []) if k < off]
        self.data["tracks"][track].append(b)
        self._sort(track)
        return b

    def _in_transition(self, track, c, t):
        """True where time t falls inside a transition into or out of clip c (R9-13)."""
        if track not in ("video", "titles"):
            return False
        d = self._overlap_in(track, c)
        if d and t < c["start"] + d - EPS:
            return True
        nxt = self.neighbours(c["id"])[1]
        if nxt is not None and self._overlap_in(track, nxt) and t > nxt["start"] + EPS:
            return True
        return False

    def split(self, cid, t):
        """Split at time t (R3-01). Returns the new (second) clip."""
        track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        if not (c["start"] + 0.04 <= t <= end_of(c) - 0.04):
            raise EditError("The playhead isn't over that clip.")
        if self._in_transition(track, c, t):
            raise EditError("The playhead is inside a transition: split before or after it.")
        self.checkpoint("Split")
        b = self._split(track, c, t)
        self._regroup_halves([b])
        self._changed()
        return b

    def split_at(self, t, ids=None):
        """Split every clip under time t (or just the given ones)."""
        hit = [c for c in self.clips_at(t) if (ids is None or c["id"] in ids)
               and c["start"] + 0.04 <= t <= end_of(c) - 0.04]
        if not hit:
            raise EditError("There's no clip under the playhead to split.")
        clear = [c for c in hit if not self._in_transition(self.find(c["id"])[0], c, t)]
        if not clear:
            raise EditError("The playhead is inside a transition: split before or after it.")
        if len(clear) < len(hit):
            # the picture is mid-transition: leave its own sound whole as well, so the pair stays a pair
            skip = {c.get("group") for c in hit if c not in clear} - {None}
            clear = [c for c in clear if c.get("group") not in skip]
            if not clear:
                raise EditError("The playhead is inside a transition: split before or after it.")
        hit = clear
        self.checkpoint("Split")
        out = []
        for c in hit:
            out.append(self._split(self.find(c["id"])[0], c, t))
        self._regroup_halves(out)
        self._changed()
        return out

    def _regroup_halves(self, halves):
        """The second halves of a split are a group of their own: a picture and its sound split
        together stay a pair, but the two sides of the cut can be moved apart (before this, all
        four pieces stayed one group and moved as one)."""
        fresh, count = {}, {}
        for b in halves:
            if b.get("group"):
                count[b["group"]] = count.get(b["group"], 0) + 1
        for b in halves:
            g = b.get("group")
            if not g:
                continue
            if count[g] < 2:
                b.pop("group", None)
            else:
                b["group"] = fresh.setdefault(g, self._new_id())
        # a first half left alone in its group is on its own too
        for g in count:
            left = self.group_members(g)
            if len(left) == 1:
                left[0].pop("group", None)

    def delete(self, ids, ripple=False):
        """Delete clips; ripple=True closes the gap they leave (R3-01 ripple delete)."""
        if not ids:
            return
        self.checkpoint("Ripple Delete" if ripple else "Delete")
        gone = []
        for cid in ids:
            track, c = self.find(cid)
            if c is None:
                continue
            nxt = self.neighbours(cid)[1]
            # the gap this clip leaves: from where the clip before it ends to where the next one
            # starts once its own transition is off (R9-13)
            prev = self.neighbours(cid)[0]
            d_in = max(0.0, end_of(prev) - c["start"]) if prev is not None else 0.0
            d_out = max(0.0, end_of(c) - nxt["start"]) if nxt is not None else 0.0
            self.data["tracks"][track].remove(c)
            if nxt is not None and nxt.get("transition"):
                nxt["transition"] = None
            gone.append((track, c["start"] + d_in, max(0.0, c["duration"] - d_in - d_out),
                         (nxt["start"] if nxt is not None else end_of(c))))
        if ripple:
            # Gaps that are the same on several tracks (a picture and its sound deleted together)
            # close together, once. A gap on one track alone still carries the later clips'
            # partners on the other tracks, so a picture and its sound stay together (R9-05).
            groups = {}
            for track, start, length, at in gone:
                groups.setdefault((round(start, 4), round(length, 4)), []).append((track, at))
            for (start, length), where in sorted(groups.items(), key=lambda kv: -kv[0][0]):
                tracks = sorted({t for t, _a in where})
                at = min(a for _t, a in where)
                # the gap closes as far as the tracks carried along have room for
                self._ripple(tracks, -min(length, self._room(tracks, at)), at)
        for t in ("video", "titles"):
            self._settle(t)
        self._changed()

    def move_many(self, ids, delta, tolerance=0.0, playhead=None):
        """Slide several clips (and their groups) along together, keeping their spacing and their
        tracks (R9-26). Nothing moves unless every one of them can."""
        ids = self.expand_groups(list(ids))
        members = sorted([c for c in self.all_clips() if c["id"] in ids], key=lambda c: c["start"])
        if not members:
            raise EditError("no such clips")
        first = members[0]
        start = max(0.0, first["start"] + delta)
        if tolerance:
            last_end = max(end_of(c) for c in members)
            extra = [playhead] if playhead is not None else []
            span = last_end - first["start"]
            s1 = self.snap(start, tolerance, exclude=ids, extra=extra)
            s2 = self.snap(start + span, tolerance, exclude=ids, extra=extra) - span
            moved = [s for s in (s1, s2) if abs(s - start) > 1e-9]
            if moved:
                start = min(moved, key=lambda s: abs(s - start))
        delta = start - first["start"]
        if abs(delta) < EPS:
            return 0.0
        idset = set(ids)
        for c in members:
            at = c["start"] + delta
            if at < -EPS:
                raise EditError("The clips would run off the start of the timeline.")
            track = self.find(c["id"])[0]
            for x in self.data["tracks"][track]:
                if x["id"] in idset:
                    continue
                if not (end_of(x) <= at + EPS or x["start"] >= at + c["duration"] - EPS):
                    raise EditError("Something is in the way of the clips there.")
        self.checkpoint("Move")
        for c in members:
            c["start"] = max(0.0, c["start"] + delta)
        for t in TRACKS:
            self._sort(t)
        for t in ("video", "titles"):
            self._settle(t)
        self._changed()
        return delta

    def move(self, cid, start, track=None, tolerance=0.0, playhead=None, solo=False):
        """Move a clip (optionally to another track). It snaps to clip edges and the playhead, and
        never lands on top of another clip: it goes to the nearest free place instead. A clip in a
        group takes its group with it and stays on its own track, so a picture and the sound split
        off it cannot be parted by any route (R5-05); solo=True moves just this one."""
        old_track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        gid = None if solo else self.group_of(cid)
        if gid:
            return self.move_group(gid, start - c["start"], tolerance=tolerance, playhead=playhead)
        track = track or old_track
        if track != old_track:
            if c["kind"] != "media" and track != "titles":
                raise EditError("Titles stay on the Titles track.")
            if c["kind"] == "media":
                m = self.media_by_uri(c["media"])
                if track in ("audio", "music") and not m.get("has_audio"):
                    raise EditError("That clip has no sound.")
                if track in ("video", "titles") and not (m.get("has_video") or m.get("is_image")):
                    raise EditError("That clip has no picture.")
        self.checkpoint("Move")
        start = max(0.0, start)
        if tolerance:
            extra = [playhead] if playhead is not None else []
            s1 = self.snap(start, tolerance, exclude=(cid,), extra=extra)
            s2 = self.snap(start + c["duration"], tolerance, exclude=(cid,), extra=extra) - c["duration"]
            moved = [s for s in (s1, s2) if abs(s - start) > 1e-9]   # only an edge that snapped counts
            if moved:
                start = min(moved, key=lambda s: abs(s - start))
        self.data["tracks"][old_track].remove(c)
        c["transition"] = None
        lst = self.data["tracks"][track]
        # the nearest free place: where it was dropped, else just after or before what's there
        def free(at):
            return all(end_of(x) <= at + EPS or x["start"] >= at + c["duration"] - EPS for x in lst)
        if not free(start):
            cands = [end_of(x) for x in lst] + [x["start"] - c["duration"] for x in lst]
            cands = [p for p in cands if p >= -EPS and free(max(0.0, p))]
            if not cands:
                cands = [max([end_of(x) for x in lst] + [0.0])]
            start = min(cands, key=lambda p: abs(p - start))
        c["start"] = max(0.0, start)
        lst.append(c)
        self._sort(track)
        for t in {old_track, track}:
            self._settle(t)
        self._changed()
        return c

    def paste(self, items, at):
        """Copied clips back on their tracks from time `at`, keeping their spacing; each goes to
        the first free place. items: [{"track", "clip", "offset", "media"}]. Returns the new clips."""
        if not items:
            return []
        self.checkpoint("Paste")
        out = []
        regroup = {}       # a pasted group is a group of its own, not the one copied from (R4-06)
        # One place for the whole paste, so the clips keep their spacing: a picture and its sound
        # that each went to "the first free place" of their own could land apart (R9-14).
        at = max(0.0, at)
        for _try in range(60):
            push = 0.0
            for it in items:
                want = at + it["offset"]
                got = self._first_free(it["track"], want, it["clip"]["duration"])
                push = max(push, got - want)
            if push <= EPS:
                break
            at += push
        renamed = {}
        for it in sorted(items, key=lambda x: x["offset"]):
            c = copy.deepcopy(it["clip"])
            if c.get("group"):
                c["group"] = regroup.setdefault(c["group"], self._new_id())
            if c["kind"] == "media" and self.media_by_uri(c["media"]) is None:
                if not it.get("media"):
                    continue
                self.data["media"].append(copy.deepcopy(it["media"]))
            old_id = c["id"]
            c["id"] = self._new_id()
            renamed[old_id] = c["id"]
            c["transition"] = None
            track = it["track"]
            c["start"] = self._first_free(track, max(0.0, at + it["offset"]), c["duration"])
            self.data["tracks"][track].append(c)
            self._sort(track)
            out.append(c)
        # a copy knows its own partner, never the clip it was copied from (R9-14)
        for c in out:
            for key in ("sound_clip", "picture_clip"):
                if key in c:
                    if c[key] in renamed:
                        c[key] = renamed[c[key]]
                    else:
                        c.pop(key)
        self._changed("all" if any(it.get("media") for it in items) else "timeline")
        return out

    def trim(self, cid, edge, t, tolerance=0.0, playhead=None, solo=False):
        """Drag a clip's start or end edge to time t (R3-01 trim). The media's own length and the
        neighbouring clips are the limits. solo=True trims this clip alone, leaving the rest of its
        group where it is (R5-08)."""
        track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        if tolerance:
            t = self.snap(t, tolerance, exclude=(cid,), extra=[playhead] if playhead is not None else [])
        prev, nxt = self.neighbours(cid)
        self.checkpoint("Trim")
        # a picture and the sound split off it share both edges: trimming one trims the other, or
        # the two would drift apart the moment you shortened a clip (R5-05)
        together = [] if solo else [
            m for m in self.group_members(c.get("group")) if m["id"] != cid
            and abs(m["start"] - c["start"]) <= EPS and abs(m["duration"] - c["duration"]) <= EPS]
        # the edge goes only as far as every clip trimmed with it can follow: a picture stopped by
        # the next clip must not leave its sound running on past it
        for m in together:
            mp, mn = self.neighbours(m["id"])
            t = self._trim_clamp(m, edge, t, mp, mn)
        got = self._trim_one(cid, c, edge, t, prev, nxt)
        for m in together:
            mp, mn = self.neighbours(m["id"])
            self._trim_one(m["id"], m, edge, got["start"] if edge == "start" else end_of(got), mp, mn)
        for t in ("video", "titles"):
            self._settle(t)
        self._changed()
        return got

    def _trim_clamp(self, c, edge, t, prev, nxt):
        """Where this clip's edge can actually go when asked for time t."""
        sp = c.get("speed", 1.0)
        m = self.media_by_uri(c["media"]) if c["kind"] == "media" else None
        if edge == "start":
            lo = end_of(prev) - self._overlap_in(self.find(c["id"])[0], c) if prev else 0.0
            if m is not None and not m.get("is_image"):
                lo = max(lo, c["start"] - c["inpoint"] / sp)
            least = min(0.1, c["duration"])          # a clip already shorter than that stays as long (R9-32)
            return min(max(t, lo), max(lo, end_of(c) - least))
        hi = nxt["start"] + self._overlap_in(self.find(nxt["id"])[0], nxt) if nxt else float("inf")
        hi = min(hi, c["start"] + self.max_duration(c))
        least = c["start"] + min(0.1, c["duration"])
        return max(min(t, hi), min(least, hi))

    def _trim_one(self, cid, c, edge, t, prev, nxt):
        track, _c = self.find(cid)
        sp = c.get("speed", 1.0)
        t = self._trim_clamp(c, edge, t, prev, nxt)
        if edge == "start":
            delta = t - c["start"]
            if c["kind"] == "media":
                c["inpoint"] = max(0.0, c["inpoint"] + delta * sp)
            c["start"] = t
            c["duration"] -= delta
        else:
            c["duration"] = t - c["start"]
        c["fade_in"] = min(c["fade_in"], c["duration"])
        c["fade_out"] = min(c["fade_out"], c["duration"])
        self._sort(track)
        return c

    def trim_to_playhead(self, cid, t, edge):
        """Ribbon Trim Start / Trim End: the clip's start (or end) moves to the playhead. The
        playhead has to be over the clip: from outside it this used to cut the clip down to a
        tenth of a second (R9-27)."""
        _track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        if not (c["start"] + 0.04 <= t <= end_of(c) - 0.04):
            raise EditError("Move the playhead over “%s” first." % c["name"])
        return self.trim(cid, edge, t)

    def set(self, cid, label="Change", merge=False, **props):
        """Change clip properties (volume, fade_in, color, text, ...). merge=True: repeated changes
        of the same properties (a slider) are one undo step."""
        track, c = self.find(cid)
        if c is None:
            raise EditError("no such clip")
        self.checkpoint(label, merge=(cid, tuple(sorted(props))) if merge else None)
        for k, v in props.items():
            if isinstance(v, dict) and isinstance(c.get(k), dict):
                c[k] = dict(c[k], **v)
            else:
                c[k] = v
        if "fade_in" in props or "fade_out" in props:
            c["fade_in"] = max(0.0, min(c["fade_in"], c["duration"]))
            c["fade_out"] = max(0.0, min(c["fade_out"], c["duration"]))
        if c["kind"] != "media" and "text" in props:
            c["name"] = props["text"].split("\n")[0][:40] or c["name"]
        self._changed("props")
        return c

    def set_speed(self, cid, speed, solo=False):
        """Speed (R3-03): 0.25× to 4×. The clip gets shorter or longer on the timeline; clips after it
        on the track move to keep the cut where it was. solo=True changes this clip alone (R5-08)."""
        track, c = self.find(cid)
        if c is None or c["kind"] != "media":
            raise EditError("Speed is for video and sound clips.")
        speed = max(0.25, min(4.0, float(speed)))
        self.checkpoint("Speed")
        # a picture and the sound split off it run at the same speed, or they stop lining up (R5-05)
        both = [c] + [m2 for m2 in ([] if solo else self.group_members(c.get("group")))
                      if m2["id"] != cid and m2["kind"] == "media" and abs(m2["start"] - c["start"]) <= EPS
                      and abs(m2["duration"] - c["duration"]) <= EPS]
        old_end = end_of(c)
        at = old_end
        for x in both:
            nxt = self.neighbours(x["id"])[1]
            if nxt is not None and nxt["start"] < at:      # the next clip reaches back over this one
                at = nxt["start"]
        old = c["duration"]
        for x in both:
            self._speed_one(x, speed)
        # everything after moves once, whichever tracks the pair is on (R9-04)
        tracks = sorted({self.find(x["id"])[0] for x in both})
        delta = c["duration"] - old
        if delta < 0:
            delta = -min(-delta, self._room(tracks, at, both))
        self._ripple(tracks, delta, at, exclude=both)
        for t in tracks:
            self._settle(t)
        self._changed()
        return c

    def _speed_one(self, c, speed):
        m = self.media_by_uri(c["media"])
        span = c["duration"] * c["speed"]                # how much of the media the clip shows
        if m is not None and not m.get("is_image"):
            span = min(span, float(m["duration"]) - c["inpoint"])
        c["speed"] = speed
        c["duration"] = span / speed
        return c

    def set_transition(self, cid, kind, duration=1.0):
        """A transition into this clip from the one before it on the track (R3-03). Crossfades and
        wipes overlap the two clips (this clip and everything after it move earlier); Fade to Black
        fades the first out and the second in."""
        track, c = self.find(cid)
        prev = self.neighbours(cid)[0] if c else None
        if c is None or prev is None:
            raise EditError("A transition goes between two clips: pick the second one.")
        if track not in ("video", "titles"):
            raise EditError("Transitions are for the Video and Titles tracks; on sound, use fades.")
        self.checkpoint("Transition")
        old = c.get("transition")
        shift = old["duration"] if old and old["type"] != "dip-black" else 0.0
        if kind in (None, "none"):
            new_shift = 0.0
            c["transition"] = None
        else:
            gap = c["start"] - end_of(prev)
            if gap > 0.05 and kind != "dip-black":
                raise EditError("The two clips must touch for a transition: close the gap first.")
            if min(c["duration"], prev["duration"]) < 0.2 and not old:
                raise EditError("Those clips are too short for a transition.")
            duration = max(0.1, min(float(duration), c["duration"] / 2, prev["duration"] / 2))
            new_shift = duration if kind != "dip-black" else 0.0
            c["transition"] = {"type": kind, "duration": duration}
        delta = shift - new_shift
        if abs(delta) > EPS:
            self._ripple([track], delta, c["start"])
        self._sort(track)
        self._settle(track)
        self._changed()
        return c

    def set_keyframes(self, cid, points):
        """Volume points [(time in the clip, level 0..2), ...] (R3-05)."""
        return self.set(cid, label="Volume Points", keyframes=sorted([[float(t), float(v)] for t, v in points]))

    # ------------------------------------------------------------ the music bed (R3-05)
    def duck_points(self, music, level=0.3, ramp=0.4):
        """Where the music dips: under every clip on the Audio track (speech, voice-over).
        Returns [(t in the clip, gain)]."""
        # Speech is what was put on the Audio track on purpose: a voice-over, an interview's sound.
        # A picture's own sound, which sits there too since R5-05, is not: counting it kept the
        # music down for the whole film (R9-28).
        own = set()
        for name in ("video", "titles"):
            for pic in self.data["tracks"][name]:
                snd = self.sound_partner(pic["id"]) if pic.get("sound_elsewhere") else None
                if snd is not None:
                    own.add(snd["id"])
        speech = []
        for x in self.data["tracks"]["audio"]:
            if not x.get("muted") and x["id"] not in own:
                speech.append((x["start"], end_of(x)))
        speech.sort()
        merged = []
        for a, b in speech:
            if merged and a <= merged[-1][1] + ramp * 2:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        s, e = music["start"], end_of(music)
        pts = [(0.0, 1.0)]
        for a, b in merged:
            if b <= s or a >= e:
                continue
            for t, g in ((a - ramp, 1.0), (a, level), (b, level), (b + ramp, 1.0)):
                if s - EPS <= t <= e + EPS:
                    pts.append((t - s, g))
                elif t < s and g == level:
                    pts.append((0.0, level))
        pts.sort()
        return pts

    # ------------------------------------------------------------ files
    def to_json(self):
        d = copy.deepcopy(self.data)
        if self.path:
            base = os.path.dirname(os.path.abspath(self.path))
            for m in d["media"]:
                p = uri_to_path(m["uri"])
                if p:
                    try:
                        m["relative"] = os.path.relpath(p, base)
                    except ValueError:
                        pass
        return json.dumps(d, indent=1)

    def save(self, path=None):
        path = path or self.path
        if not path:
            raise EditError("no file name")
        self.path = path
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(self.to_json())
        os.replace(tmp, path)
        self.mark_saved()

    @classmethod
    def load(cls, path):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except UnicodeDecodeError:
            raise EditError("That isn't a Folio Reel project.")
        except ValueError:
            raise EditError("That isn't a Folio Reel project, or the file is damaged.")
        data = check_project(data)
        base = os.path.dirname(os.path.abspath(path))
        uri_map = {}
        for m in data.get("media", []):
            # media moved along with the project (e.g. a folder copied to another computer)
            p = uri_to_path(m["uri"])
            rel = m.pop("relative", None)
            if not p or os.path.exists(p):
                continue
            found = None
            if rel and os.path.exists(os.path.join(base, rel)):
                found = os.path.normpath(os.path.join(base, rel))
            elif os.path.exists(os.path.join(base, os.path.basename(p))):
                found = os.path.join(base, os.path.basename(p))      # beside the project, by name (R9-02)
            if found:
                new = path_to_uri(found)
                uri_map[m["uri"]] = new
                m["uri"] = new
        for t in data["tracks"].values():
            for c in t:
                if c.get("media") in uri_map:
                    c["media"] = uri_map[c["media"]]
                for k, v in clip_defaults().items():
                    c.setdefault(k, copy.deepcopy(v))
        p = cls(data, path)
        p.mark_saved()
        return p

    def missing_media(self):
        self.refresh_missing()
        return [m for m in self.data["media"] if m["uri"] in self.missing]

    def missing_clips(self):
        """Clips whose media file is not there, or is not in the bin at all."""
        return [c for c in self.all_clips() if c["kind"] == "media"
                and (c.get("media") in self.missing or self.media_by_uri(c.get("media")) is None)]


class _Batch:
    def __init__(self, project, label):
        self.p, self.label = project, label

    def __enter__(self):
        p = self.p
        if p._batch == 0:
            p._batch_made = False
            p._batch_label = self.label
        p._batch += 1
        return p

    def __exit__(self, *exc):
        self.p._batch -= 1
        if self.p._batch == 0:
            self.p._merge = None
        return False


def _number(v, default=None):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if f == f and abs(f) != float("inf") else default


def check_project(data):
    """A project read from a file, made safe to work with, or EditError if it is not one (R9-15).
    Missing settings get their usual values; a clip that cannot be placed is left out."""
    if not isinstance(data, dict) or not isinstance(data.get("tracks"), dict):
        raise EditError("That isn't a Folio Reel project.")
    w, h, fps = _number(data.get("width")), _number(data.get("height")), _number(data.get("fps"))
    data["width"] = int(w) if w and w >= 16 else 1920
    data["height"] = int(h) if h and h >= 16 else 1080
    data["fps"] = int(fps) if fps and 1 <= fps <= 240 else 30
    media = [m for m in (data.get("media") if isinstance(data.get("media"), list) else [])
             if isinstance(m, dict) and isinstance(m.get("uri"), str)]
    for m in media:
        m.setdefault("name", os.path.basename(uri_to_path(m["uri"]) or m["uri"]))
        m["duration"] = _number(m.get("duration"), IMAGE_SECONDS) or IMAGE_SECONDS
    data["media"] = media
    seen, top = set(), 0
    for name in list(data["tracks"]):
        if name not in TRACKS:
            del data["tracks"][name]
    for name in TRACKS:
        good = []
        lst = data["tracks"].get(name)
        for c in (lst if isinstance(lst, list) else []):
            if not isinstance(c, dict):
                continue
            start, dur = _number(c.get("start")), _number(c.get("duration"))
            kind = c.get("kind")
            if start is None or dur is None or dur <= 0 or kind not in ("media", "title", "lower-third", "caption"):
                continue
            if kind == "media" and not isinstance(c.get("media"), str):
                continue
            cid = c.get("id")
            if not isinstance(cid, int) or cid in seen:
                cid = None
            c["start"], c["duration"] = max(0.0, start), dur
            c["inpoint"] = max(0.0, _number(c.get("inpoint"), 0.0) or 0.0)
            sp = _number(c.get("speed"), 1.0) or 1.0
            c["speed"] = max(0.25, min(4.0, sp))
            c.setdefault("name", kind.title())
            if kind != "media":
                c.setdefault("text", "")
            tr = c.get("transition")
            if tr is not None and not (isinstance(tr, dict) and isinstance(tr.get("type"), str)
                                       and _number(tr.get("duration"))):
                c["transition"] = None
            c["_id"] = cid
            good.append(c)
            if cid is not None:
                seen.add(cid)
                top = max(top, cid)
        data["tracks"][name] = good
    markers = []
    for m in (data.get("markers") if isinstance(data.get("markers"), list) else []):
        if isinstance(m, dict) and _number(m.get("t")) is not None:
            m["t"] = max(0.0, _number(m["t"]))
            m.setdefault("name", "")
            if not isinstance(m.get("id"), int):
                m["id"] = None
            else:
                top = max(top, m["id"])
            markers.append(m)
    data["markers"] = markers
    for name in TRACKS:
        for c in data["tracks"][name]:
            if c.pop("_id") is None:
                top += 1
                c["id"] = top
            g = c.get("group")
            if isinstance(g, int):
                top = max(top, g)
        data["tracks"][name].sort(key=lambda c: (c["start"], c["id"]))
    for m in markers:
        if m["id"] is None:
            top += 1
            m["id"] = top
    nid = data.get("next_id")
    data["next_id"] = max(nid if isinstance(nid, int) else 0, top + 1)
    data.setdefault("version", 1)
    return data


def uri_to_path(uri):
    if uri.startswith("file://"):
        from urllib.parse import unquote, urlparse
        return unquote(urlparse(uri).path)
    return None


def path_to_uri(path):
    from urllib.parse import quote
    return "file://" + quote(os.path.abspath(path))


def parse_time(text, fps=None):
    """A time the person typed, as seconds, or None. Takes "12", "1:30", "1:02:03" and the
    timecode's own "0:01:30:12" (hours:minutes:seconds:frames), with or without the frames (R5-01)."""
    t = (text or "").strip().replace(";", ":").replace(",", ".")
    if not t:
        return None
    parts = t.split(":")
    if len(parts) > 4:
        return None
    try:
        if len(parts) == 4:
            h, m, sec, f = parts
            return int(h) * 3600 + int(m) * 60 + int(sec) + (float(f) / (fps or 25))
        nums = [float(x) for x in parts]
    except ValueError:
        return None
    secs = 0.0
    for n in nums:
        secs = secs * 60 + n
    if secs != secs or secs == float("inf"):
        return None
    return max(0.0, secs)


def fmt_time(secs, frames_fps=None):
    secs = max(0.0, secs)
    if frames_fps:
        total = int(round(secs * frames_fps))
        f = total % frames_fps
        s = total // frames_fps
        return "%d:%02d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60, f)
    s = int(secs)
    if s >= 3600:
        return "%d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60)
    return "%d:%02d.%d" % (s // 60, s % 60, int((secs - s) * 10))
