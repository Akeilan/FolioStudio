"""Moving and sizing an inset by hand, on the preview (R10-02).

A see-through layer over the preview picture. With one inset clip selected and the playhead over
it, it outlines the inset with a handle at each corner: drag inside to move it, drag a corner to
size it (the opposite corner stays put). The change is one undoable edit, made when the mouse is
let go; while dragging only the outline moves, so the film isn't rebuilt at every step."""
from gi.repository import Gdk, Gtk

from . import engine, model

HANDLE = 7          # px: the corner squares, and how near a corner a press has to be


class InsetHandles(Gtk.DrawingArea):
    def __init__(self, win):
        Gtk.DrawingArea.__init__(self)
        self.win = win
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK | Gdk.EventMask.BUTTON_RELEASE_MASK
                        | Gdk.EventMask.POINTER_MOTION_MASK)
        self.connect("draw", self._draw)
        self.connect("button-press-event", self._press)
        self.connect("motion-notify-event", self._motion)
        self.connect("button-release-event", self._release)
        self.drag = None            # (mode, start pointer, start rect) while dragging
        self.live = None            # the rect being dragged, in frame pixels

    # ------------------------------------------------------------ which inset, where
    def target(self):
        """(clip, media) of the one selected inset under the playhead, or None."""
        win = self.win
        if getattr(win, "playing", False):
            return None
        sel = win.picture_clips() if hasattr(win, "picture_clips") else []
        if len(sel) != 1:
            return None
        c = sel[0]
        if model.inset_of(c) is None or c.get("hidden"):
            return None
        t = getattr(win, "playhead", 0.0)
        if not (c["start"] - 1e-6 <= t < model.end_of(c)):
            return None
        m = win.project.media_by_uri(c["media"])
        return (c, m) if m else None

    def frame_rect(self):
        """The selected inset's (x, y, w, h) in the frame's own pixels, or None."""
        tg = self.target()
        if tg is None:
            return None
        p = self.win.project
        r = engine.inset_rect(tg[1], tg[0], p.width, p.height)
        return r[:4] if r else None

    def scale(self):
        return self.get_allocated_width() / float(max(1, self.win.project.width))

    def widget_rect(self, r):
        k = self.scale()
        return (r[0] * k, r[1] * k, r[2] * k, r[3] * k)

    # ------------------------------------------------------------ drawing
    def _draw(self, _w, cr):
        r = self.live or self.frame_rect()
        if r is None:
            return False
        x, y, w, h = self.widget_rect(r)
        cr.set_line_width(1.5)
        cr.set_source_rgba(1, 1, 1, 0.95)
        cr.rectangle(x + 0.5, y + 0.5, w - 1, h - 1)
        cr.stroke()
        cr.set_dash([4, 4])
        cr.set_source_rgba(0.12, 0.23, 0.41, 0.95)
        cr.rectangle(x + 0.5, y + 0.5, w - 1, h - 1)
        cr.stroke()
        cr.set_dash([])
        for hx, hy in ((x, y), (x + w, y), (x, y + h), (x + w, y + h)):
            cr.set_source_rgba(1, 1, 1, 1)
            cr.rectangle(hx - HANDLE / 2.0, hy - HANDLE / 2.0, HANDLE, HANDLE)
            cr.fill_preserve()
            cr.set_source_rgba(0.12, 0.23, 0.41, 1)
            cr.set_line_width(1)
            cr.stroke()
        return False

    # ------------------------------------------------------------ dragging
    def hit(self, ex, ey):
        """'corner:<i>' (0 top left, 1 top right, 2 bottom left, 3 bottom right), 'move' or None."""
        r = self.frame_rect()
        if r is None:
            return None
        x, y, w, h = self.widget_rect(r)
        for i, (hx, hy) in enumerate(((x, y), (x + w, y), (x, y + h), (x + w, y + h))):
            if abs(ex - hx) <= HANDLE and abs(ey - hy) <= HANDLE:
                return "corner:%d" % i
        if x <= ex <= x + w and y <= ey <= y + h:
            return "move"
        return None

    def _press(self, _w, ev):
        if ev.type == Gdk.EventType._2BUTTON_PRESS:
            self.win.run("full-screen")
            return True
        if ev.button != 1:
            return False
        mode = self.hit(ev.x, ev.y)
        if mode is None:
            return False
        self.drag = (mode, (ev.x, ev.y), self.frame_rect())
        self.live = self.drag[2]
        return True

    def _motion(self, _w, ev):
        if self.drag is None:
            mode = self.hit(ev.x, ev.y)
            win = self.get_window()
            if win is not None:
                name = {"move": "move", "corner:0": "nw-resize", "corner:1": "ne-resize",
                        "corner:2": "sw-resize", "corner:3": "se-resize"}.get(mode)
                win.set_cursor(Gdk.Cursor.new_from_name(self.get_display(), name) if name else None)
            return False
        self.live = self.moved(self.drag, ev.x, ev.y)
        self.queue_draw()
        return True

    def moved(self, drag, ex, ey):
        """The rect a drag has made so far (frame pixels): moved, or sized from a corner keeping the
        picture's shape and the opposite corner where it was. It stays inside the frame."""
        mode, (sx, sy), (x, y, w, h) = drag
        p = self.win.project
        W, H = float(p.width), float(p.height)
        k = self.scale()
        dx, dy = (ex - sx) / k, (ey - sy) / k
        if mode == "move":
            return (max(0.0, min(W - w, x + dx)), max(0.0, min(H - h, y + dy)), w, h)
        i = int(mode.split(":")[1])
        left, top = i in (0, 2), i in (0, 1)
        ax, ay = (x + w, y + h) if left and top else (x, y + h) if top else (x + w, y) if left else (x, y)
        # the new width from whichever way the pointer moved further, keeping the shape
        nw = w + (-dx if left else dx)
        nh_from_w = nw * h / w
        nh = h + (-dy if top else dy)
        if abs(nh - h) * w > abs(nw - w) * h:
            nw = nh * w / h
        else:
            nh = nh_from_w
        room_w = ax if left else W - ax
        room_h = ay if top else H - ay
        s = max(0.05 * min(W, H) / max(1.0, min(w, h)), min(nw / w, nh / h, room_w / w, room_h / h))
        nw, nh = w * s, h * s
        nx = ax - nw if left else ax
        ny = ay - nh if top else ay
        return (nx, ny, nw, nh)

    def _release(self, _w, ev):
        if self.drag is None:
            return False
        r = self.moved(self.drag, ev.x, ev.y)
        moved = any(abs(a - b) > 0.5 for a, b in zip(r, self.drag[2]))
        self.drag = None
        self.live = None
        tg = self.target()
        if moved and tg is not None:
            self.commit(tg[0], tg[1], r)
        self.queue_draw()
        return True

    def inset_for(self, c, media, r):
        """The inset settings that put the clip's picture at rect r (frame pixels)."""
        p = self.win.project
        W, H = float(p.width), float(p.height)
        ins = model.inset_of(c) or dict(model.DEFAULT_INSET)
        old = engine.inset_rect(media, c, W, H)
        # size scales with the picture; the place is where it sits in the room left
        size = max(0.05, min(1.0, ins["size"] * r[2] / float(max(1, old[2]))))
        trial = dict(c, inset=dict(ins, size=size))
        nr = engine.inset_rect(media, trial, W, H)
        m = 0.03 * min(W, H) if size < 0.999 else 0.0
        roomx, roomy = W - 2 * m - nr[2], H - 2 * m - nr[3]
        x = (r[0] - m) / roomx if roomx > 1 else 0.5
        y = (r[1] - m) / roomy if roomy > 1 else 0.5
        return dict(ins, size=round(size, 3), x=round(max(0.0, min(1.0, x)), 3), y=round(max(0.0, min(1.0, y)), 3))

    def commit(self, c, media, r):
        new = self.inset_for(c, media, r)
        self.win.edit(lambda p: p.set(c["id"], label="Move Inset", inset=new))
        return new
