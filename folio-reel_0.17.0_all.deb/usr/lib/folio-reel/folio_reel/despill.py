"""Spill suppression for the chroma key (R4-02): light bounced off a green or blue screen tints the
edges of hair and clothes, and the key leaves that tint behind. This takes the key colour back down
to the brightest of the other two in every pixel, which is what a despill does in any editor.

GStreamer has no element for it, so this is one, written here and registered for this process
only. It needs GStreamer's Python bindings and numpy; without them `available()` is False and the
Spill setting isn't offered."""
import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstBase", "1.0")
gi.require_version("GstVideo", "1.0")
from gi.repository import GObject, Gst, GstBase, GstVideo  # noqa: E402

NAME = "foliodespill"
_state = {"tried": False, "ok": False}


def available():
    """Register the element the first time; True when it can be used."""
    if _state["tried"]:
        return _state["ok"]
    _state["tried"] = True
    try:
        import numpy  # noqa: F401
        from gi.repository import GstBase as _gb  # noqa: F401
        Gst.init(None)
        if Gst.ElementFactory.find(NAME) is None:
            GObject.type_register(_element_class())
            if not Gst.Element.register(None, NAME, Gst.Rank.NONE, _element_class()):
                return False
        _state["ok"] = Gst.ElementFactory.find(NAME) is not None
    except Exception:       # noqa: BLE001 - no bindings, no numpy: the setting just isn't offered
        _state["ok"] = False
    return _state["ok"]


def description(channel, amount):
    """The piece of an effect's description that takes the spill off. channel: 0 red, 1 green,
    2 blue; amount 0..1."""
    return "videoconvert ! %s channel=%d amount=%f ! videoconvert" % (NAME, int(channel), float(amount))


_cls = []


def _element_class():
    if _cls:
        return _cls[0]
    import numpy as np
    caps = Gst.Caps.from_string("video/x-raw,format=RGBA")

    class Despill(GstBase.BaseTransform):
        __gstmetadata__ = ("Despill", "Filter/Effect/Video", "Takes a chroma key's colour spill off", "Folio Reel")
        __gsttemplates__ = (Gst.PadTemplate.new("src", Gst.PadDirection.SRC, Gst.PadPresence.ALWAYS, caps),
                            Gst.PadTemplate.new("sink", Gst.PadDirection.SINK, Gst.PadPresence.ALWAYS, caps))
        __gproperties__ = {
            "amount": (float, "amount", "How much of the spill comes off, 0 to 1", 0.0, 1.0, 1.0, GObject.ParamFlags.READWRITE),
            "channel": (int, "channel", "The key colour: 0 red, 1 green, 2 blue", 0, 2, 1, GObject.ParamFlags.READWRITE),
        }

        def __init__(self):
            super().__init__()
            self.amount, self.channel = 1.0, 1
            self.w = self.h = self.stride = 0

        def do_get_property(self, prop):
            return getattr(self, prop.name)

        def do_set_property(self, prop, value):
            setattr(self, prop.name, value)

        def do_set_caps(self, incaps, outcaps):
            info = GstVideo.VideoInfo.new_from_caps(incaps) if hasattr(GstVideo.VideoInfo, "new_from_caps") else None
            if info is None:
                info = GstVideo.VideoInfo()
                info.from_caps(incaps)
            self.w, self.h, self.stride = info.width, info.height, info.stride[0]
            return True

        def do_transform_meta(self, outbuf, meta, inbuf):
            # every meta goes along: GES places each picture by a meta of its own, and a picture
            # that lost it was drawn nowhere
            return True

        def do_transform(self, inbuf, outbuf):
            ok, mi = inbuf.map(Gst.MapFlags.READ)
            if not ok:
                return Gst.FlowReturn.ERROR
            try:
                rows = np.frombuffer(mi.data, dtype=np.uint8).reshape(self.h, self.stride)
                px = rows[:, :self.w * 4].reshape(self.h, self.w, 4).astype(np.int16)
            finally:
                inbuf.unmap(mi)
            c = self.channel
            a, b = [x for x in (0, 1, 2) if x != c]
            over = px[..., c] - np.maximum(px[..., a], px[..., b])
            np.maximum(over, 0, out=over)
            px[..., c] -= (over * self.amount).astype(np.int16)
            out = np.zeros((self.h, self.stride), dtype=np.uint8)
            out[:, :self.w * 4] = px.astype(np.uint8).reshape(self.h, self.w * 4)
            outbuf.fill(0, out.tobytes())
            return Gst.FlowReturn.OK

    _cls.append(Despill)
    return Despill
