"""Home Sharing (C4-01): share this library with the other Folio Chords on the same network, and
play from theirs. Plain HTTP over the local network, with no account and nothing sent off it: a
shared library answers a question asked on the local network, serves the song details it holds and
streams the songs themselves. Sharing is off until it is turned on, and can ask for a passcode."""
import hmac
import json
import os
import re
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from . import VERSION

PORT = 3691                  # HTTP, and the same number for the question asked over UDP
PROBE = b"FOLIO-SHARE?1"
PASS_HEADER = "X-Folio-Pass"
AGENT = "FolioChord/%s" % VERSION
MIN_PASSCODE = 6             # characters a new passcode needs (C11-01)
FREE_TRIES = 5               # wrong passcodes from one computer before each try has to wait
MAX_WAIT = 300.0             # the longest wait between tries, in seconds


def parse_range(header, size):
    """(start, end) for an HTTP Range header against a file of size bytes: None when there is no
    usable range (the whole file is sent), "bad" when it asks for nothing inside the file (C11-07).
    Handles "a-b", "a-" and the suffix form "-n" (the last n bytes); only the first of several."""
    m = re.match(r"\s*bytes\s*=\s*(\d*)\s*-\s*(\d*)\s*(?:,|$)", header or "")
    if not m or (not m.group(1) and not m.group(2)) or size <= 0:
        return None
    a, b = m.group(1), m.group(2)
    if not a:                                   # the last n bytes
        n = int(b)
        if n == 0:
            return "bad"
        return max(0, size - n), size - 1
    start = int(a)
    end = min(int(b), size - 1) if b else size - 1
    if start >= size or start > end:
        return "bad"
    return start, end


def send_file(handler, p, mime, extra=None):
    """Answer a GET or HEAD for the file at p, honouring Range, on a BaseHTTPRequestHandler."""
    size = os.path.getsize(p)
    rng = parse_range(handler.headers.get("Range", ""), size)
    if rng == "bad":
        handler.send_response(416)
        handler.send_header("Content-Range", "bytes */%d" % size)
        handler.send_header("Content-Length", "0")
        handler.end_headers()
        return
    start, end = rng or (0, size - 1)
    handler.send_response(206 if rng else 200)
    handler.send_header("Content-Type", mime)
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Length", str(end - start + 1))
    for k, v in (extra or {}).items():
        handler.send_header(k, v)
    if rng:
        handler.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
    handler.end_headers()
    if handler.command == "HEAD":
        return
    left = end - start + 1
    with open(p, "rb") as f:
        f.seek(start)
        while left > 0:
            chunk = f.read(min(65536, left))
            if not chunk:
                break
            try:
                handler.wfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError):
                return                          # the other end stopped listening
            left -= len(chunk)


class Doorman:
    """Counts wrong passcodes by computer (C11-01): after FREE_TRIES, each try must wait twice as
    long as the last, up to MAX_WAIT; a right passcode clears the count."""

    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.lock = threading.Lock()
        self.bad = {}                           # address -> (wrong tries, time of the last)

    def wait_left(self, who):
        with self.lock:
            n, last = self.bad.get(who, (0, 0.0))
        if n < FREE_TRIES:
            return 0.0
        wait = min(MAX_WAIT, 2.0 ** (n - FREE_TRIES))
        return max(0.0, last + wait - self.clock())

    def wrong(self, who):
        with self.lock:
            n, _ = self.bad.get(who, (0, 0.0))
            self.bad[who] = (n + 1, self.clock())

    def right(self, who):
        with self.lock:
            self.bad.pop(who, None)


TRACK_COLS = ("id", "title", "artist", "album_artist", "album", "genre", "composer", "year",
              "track_no", "track_count", "disc_no", "disc_count", "duration", "bitrate",
              "sample_rate", "kind", "size", "rating", "play_count", "has_art", "compilation")


def host_name():
    try:
        return socket.gethostname().split(".")[0] or "Folio Chord"
    except OSError:
        return "Folio Chord"


def default_name():
    return "%s's Music" % (os.environ.get("USER") or host_name())


# ---------------------------------------------------------------- sharing this library
class Share:
    """The server: this library offered to the network. Nothing is served until start()."""

    def __init__(self, lib, name=None, passcode="", port=PORT, host="0.0.0.0"):
        self.lib = lib
        self.name = name or default_name()
        self.passcode = passcode or ""
        self.port = port
        self.host = host
        self.httpd = None
        self.udp = None
        self._threads = []
        self.doorman = Doorman()

    # ---- the song details and the files
    def info(self):
        n = len(self.lib.q("select id from tracks where not missing"))
        return {"folio": "share", "version": 1, "name": self.name, "songs": n,
                "playlist_count": len(self.playlists()), "app": VERSION,
                "needs_pass": bool(self.passcode)}

    def tracks(self):
        out = []
        for r in self.lib.tracks():
            out.append({c: (r[c] if c in r.keys() else None) for c in TRACK_COLS})
        return out

    def playlists(self):
        return [{"id": p["id"], "name": p["name"], "kind": p["kind"]}
                for p in self.lib.playlists() if p["kind"] in ("playlist", "smart")]

    def playlist(self, pid):
        return [r["id"] for r in self.lib.playlist_tracks(pid)]

    def path_of(self, tid):
        if not 0 < tid < 2 ** 62:               # a number SQLite can't hold is no song (C11-07)
            return None
        r = self.lib.track(tid)
        if r is None or r["missing"]:
            return None
        p = r["path"]
        return p if p and os.path.isfile(p) else None

    # ---- running
    def start(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        share = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = AGENT

            def log_message(self, *_a):
                pass                              # the terminal is not a log

            def _deny(self):
                if not share.passcode:
                    return False
                who = self.client_address[0]
                wait = share.doorman.wait_left(who)
                if wait > 0:
                    # too many wrong passcodes from here: no answer until the wait is over (C11-01)
                    self.send_response(429)
                    self.send_header("Retry-After", str(int(wait) + 1))
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return True
                given = self.headers.get(PASS_HEADER, "")
                if not hmac.compare_digest(given.encode("utf-8", "replace"), share.passcode.encode("utf-8")):
                    share.doorman.wrong(who)
                    self.send_error(403, "This shared library needs its passcode.")
                    return True
                share.doorman.right(who)
                return False

            def _json(self, obj, head=False):
                b = json.dumps(obj).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                if not head and self.command != "HEAD":
                    self.wfile.write(b)

            def do_GET(self):                     # noqa: N802
                head = self.command == "HEAD"
                path = urllib.parse.urlparse(self.path).path.rstrip("/")
                if path in ("/folio", "/folio/info"):
                    return self._json(share.info(), head)     # the greeting needs no passcode
                if self._deny():
                    return None
                if path == "/folio/tracks":
                    return self._json(share.tracks())
                if path == "/folio/playlists":
                    return self._json(share.playlists())
                if path.startswith("/folio/playlist/"):
                    try:
                        return self._json(share.playlist(int(path.rsplit("/", 1)[1])))
                    except (ValueError, TypeError, OverflowError):
                        return self.send_error(404)
                if path.startswith("/folio/art/"):
                    return self._art(path.rsplit("/", 1)[1])
                if path.startswith("/folio/stream/"):
                    return self._stream(path.rsplit("/", 1)[1])
                return self.send_error(404)

            def do_HEAD(self):                    # noqa: N802
                return self.do_GET()

            def _art(self, tid):
                from . import tags
                data, mime = None, "image/jpeg"
                try:
                    a = tags.artwork(share.path_of(int(tid)) or "") if share.path_of(int(tid)) else None
                    data, mime = (a[0], a[1] or mime) if a else (None, mime)
                except Exception:                 # noqa: BLE001
                    data = None
                if not data:
                    return self.send_error(404)
                self.send_response(200)
                self.send_header("Content-Type", mime)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return None

            def _stream(self, tid):
                try:
                    p = share.path_of(int(tid))
                except (ValueError, TypeError, OverflowError):
                    p = None
                if not p:
                    return self.send_error(404)
                send_file(self, p, "application/octet-stream")
                return None

        self.httpd = ThreadingHTTPServer((self.host, self.port), Handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self._spawn(self.httpd.serve_forever)
        self._start_beacon()
        return self.port

    def _start_beacon(self):
        """Answer the question asked on the local network, so no names have to be typed in."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", self.port))
        except OSError:
            self.udp = None
            return
        self.udp = s
        self._spawn(self._beacon)

    def _beacon(self):
        s = self.udp                              # kept here, so stopping mid-question is harmless
        while s is not None and self.udp is s:
            try:
                data, addr = s.recvfrom(256)
            except OSError:
                return
            if not data.startswith(b"FOLIO-SHARE?") or self.udp is not s:
                continue
            reply = dict(self.info())
            reply["port"] = self.port
            try:
                s.sendto(json.dumps(reply).encode(), addr)
            except OSError:
                return

    def _spawn(self, fn):
        t = threading.Thread(target=fn, daemon=True)
        t.start()
        self._threads.append(t)

    def stop(self):
        u, self.udp = self.udp, None
        if u is not None:
            try:
                u.close()
            except OSError:
                pass
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None


class Row(dict):
    """A song from a shared library. The song list asks for whatever columns are showing, so a
    detail the shared library didn't send reads as empty rather than failing."""

    def __missing__(self, _k):
        return None


# ---------------------------------------------------------------- finding and reading others
def probe(timeout=1.2, port=PORT, addresses=None):
    """The shared libraries that answer on the local network: [{name, host, port, songs}]."""
    found = {}
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.settimeout(0.2)
        for a in (addresses or ["255.255.255.255", "127.0.0.1"]):
            try:
                s.sendto(PROBE, (a, port))
            except OSError:
                continue
        import time
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, addr = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                d = json.loads(data.decode("utf-8", "replace"))
            except ValueError:
                continue
            if d.get("folio") != "share":
                continue
            d["host"] = addr[0]
            d.setdefault("port", port)
            found[(d["host"], d["port"])] = d
    finally:
        s.close()
    return sorted(found.values(), key=lambda d: (d.get("name") or "").lower())


class Remote:
    """A shared library on another computer, read over HTTP."""

    def __init__(self, host, port=PORT, passcode="", name=""):
        self.host, self.port, self.passcode = host, int(port), passcode or ""
        self.name = name
        self.songs = []

    @property
    def base(self):
        return "http://%s:%d" % (self.host, self.port)

    def _get(self, path, timeout=20):
        h = {"User-Agent": AGENT}
        if self.passcode:
            h[PASS_HEADER] = self.passcode
        req = urllib.request.Request(self.base + path, headers=h)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()

    def _json(self, path, timeout=20):
        return json.loads(self._get(path, timeout).decode("utf-8", "replace"))

    def info(self):
        d = self._json("/folio/info", timeout=6)
        self.name = d.get("name") or self.name
        return d

    def tracks(self):
        self.songs = [Row(t, path=self.stream_url(t["id"]), shared=True, missing=0, checked=1)
                      for t in self._json("/folio/tracks")]
        return self.songs

    def playlists(self):
        return self._json("/folio/playlists")

    def playlist(self, pid):
        """The playlist's songs in its own order, a song that is in it twice shown twice (C8-28)."""
        ids = self._json("/folio/playlist/%d" % int(pid))
        by = {t["id"]: t for t in (self.songs or self.tracks())}
        return [by[i] for i in ids if i in by]

    def headers(self):
        """What a request for one of its songs must carry: the passcode, when it has one (C8-27)."""
        return {PASS_HEADER: self.passcode} if self.passcode else None

    def stream_url(self, tid):
        return "%s/folio/stream/%d" % (self.base, int(tid))

    def art_url(self, tid):
        return "%s/folio/art/%d" % (self.base, int(tid))

    def reachable(self):
        try:
            self.info()
            return True
        except (urllib.error.URLError, OSError, ValueError):
            return False
