"""Passcodes kept out of settings.json (C8-37): in the desktop's keyring (the Secret Service that
GNOME Keyring and KWallet provide, or Windows' Credential Manager) when there is one, otherwise in
a file only you can read.

  load(name, default)   the value stored under name
  save(name, value)     store it ("" or {} removes it)
"""
import json
import os
import sys
import threading

from gi.repository import GLib

_SCHEMA = None
_OK = None


def _secret():
    """The Secret module and schema, or None when there is no keyring to use."""
    global _SCHEMA, _OK
    if _OK is False or os.environ.get("FOLIO_CHORD_NO_KEYRING"):
        return None
    try:
        import gi
        gi.require_version("Secret", "1")
        from gi.repository import Secret
    except (ImportError, ValueError):
        _OK = False
        return None
    if _SCHEMA is None:
        _SCHEMA = Secret.Schema.new("org.folio.Chord", Secret.SchemaFlags.NONE,
                                    {"name": Secret.SchemaAttributeType.STRING})
    if _OK is None:
        # a keyring that can't be reached, or that would sit waiting on a prompt, isn't used
        done = {}

        def probe():
            try:
                Secret.password_lookup_sync(_SCHEMA, {"name": "probe"}, None)
                done["ok"] = True
            except GLib.Error:
                done["ok"] = False
        t = threading.Thread(target=probe, daemon=True)
        t.start()
        t.join(3)
        _OK = bool(done.get("ok"))
        if not _OK:
            return None
    from gi.repository import Secret
    return Secret


# ---------------------------------------------------------------- Windows: Credential Manager
def _wincred():
    """The Credential Manager calls, or None (not Windows, or switched off for tests)."""
    if sys.platform != "win32" or os.environ.get("FOLIO_CHORD_NO_KEYRING"):
        return None
    import ctypes
    from ctypes import wintypes

    class CRED(ctypes.Structure):
        _fields_ = [("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
                    ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
                    ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_char)),
                    ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
                    ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR)]
    try:
        adv = ctypes.WinDLL("advapi32.dll")
    except OSError:
        return None
    return ctypes, CRED, adv


def _target(name):
    return "Folio Chord/" + name


def _win_load(name):
    w = _wincred()
    ctypes, CRED, adv = w
    p = ctypes.POINTER(CRED)()
    if not adv.CredReadW(_target(name), 1, 0, ctypes.byref(p)):     # CRED_TYPE_GENERIC
        return None
    try:
        c = p.contents
        return ctypes.string_at(c.CredentialBlob, c.CredentialBlobSize).decode("utf-8")
    finally:
        adv.CredFree(p)


def _win_save(name, text):
    ctypes, CRED, adv = _wincred()
    if text is None:
        adv.CredDeleteW(_target(name), 1, 0)
        return True
    blob = text.encode("utf-8")
    buf = ctypes.create_string_buffer(blob, len(blob))
    c = CRED()
    c.Type = 1
    c.TargetName = _target(name)
    c.CredentialBlobSize = len(blob)
    c.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))
    c.Persist = 2                                                     # CRED_PERSIST_LOCAL_MACHINE
    c.UserName = "Folio Chord"
    return bool(adv.CredWriteW(ctypes.byref(c), 0))


def _file():
    return os.path.join(GLib.get_user_config_dir(), "folio-chord", "passcodes.json")


def _read_file():
    try:
        with open(_file()) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _write_file(d):
    p = _file()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(d, f)
    os.replace(tmp, p)


def where():
    return "keyring" if (_wincred() is not None or _secret() is not None) else "file"


def load(name, default=None):
    if _wincred() is not None:
        v = _win_load(name)
        if v is None:
            return _read_file().get(name, default)
        try:
            return json.loads(v)
        except ValueError:
            return default
    S = _secret()
    if S is not None:
        try:
            v = S.password_lookup_sync(_SCHEMA, {"name": name}, None)
        except GLib.Error:
            v = None
        if v is None:
            return default
        try:
            return json.loads(v)
        except ValueError:
            return default
    return _read_file().get(name, default)


def save(name, value):
    empty = value in ("", None) or value == {}
    if _wincred() is not None and _win_save(name, None if empty else json.dumps(value)):
        return
    S = _secret()
    if S is not None:
        try:
            if empty:
                S.password_clear_sync(_SCHEMA, {"name": name}, None)
            else:
                S.password_store_sync(_SCHEMA, {"name": name}, S.COLLECTION_DEFAULT,
                                      "Folio Chord: %s" % name.replace("_", " "), json.dumps(value), None)
            return
        except GLib.Error:
            pass
    d = _read_file()
    if empty:
        d.pop(name, None)
    else:
        d[name] = value
    _write_file(d)
